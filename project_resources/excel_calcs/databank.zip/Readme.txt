----------------------------
Properties Databank 1.0
----------------------------

Description:
------------

This is a Microsoft Excel Add-In that contains a database with the most used physical and chemical properties of various compounds, orderedn and presented in a fast and easy to query way.

"Properties Databank 1.0" contains the following properties for over 450 different chemicals:

- Mole Weight.
- Melting Point.
- Boiling Point.
- Critical Temperature.
- Critical Pressure.
- Critical Volume.
- Critical Compresibility Factor.
- Ascentric Factor.
- Liquid Density.
- Dipole Moment.
- Heat Capacity of the Vapor in the ideal gas state. (As a function of the temperature.)
- Viscosity. (As a function of the temperature.)
- Standard Enthalpy of Formation.
- Standard Free Energy of Formation.
- Vapor Pressure. (As a function of the temperature.)
- Vaporizing Heat.

In addition of beeing a fast reference to these properties, the "Properties Databank 1.0" Add-In contains the following functions that can be used as the standard Microsoft Excel's worksheet functions:

- Cp(Name,Temperature): Returns the heat capacity in Cal/mol-K of the compound "Name" in the ideal gas state at the specified temperature in K.

- AntoineP(Name, Temperature): Returns the vapor pressure in mmHg of the compound "Name" at the specified temperature in K using Antoine's equation.

- AntoineT(Name, Pressure): Returns the saturation temperature in K of the compound "Name" at the specified Pressure in mmHg using Antoine's equation.

- Viscosity(Name, Temperature): Returns the viscosity in cP of the compound "Name" at the specified temperature in K.

- HarlacherP(Name, Temperature): Returns the vapor pressure in mmHg of the compound "Name" at the specified temperature in K using Harlacher's equation.

All these functions can be either directly written in the cell were they are going to be used, preceded of the "=" sign; they also appear in the cathegory or "Databank" in the functions editor; or they can directly be inserted from the "Properties Databank 1.0" window using the "Insert Function" buttons.


Instalation:
------------
For installing the "Properties Databank 1.0" Add-In you only have to follow the below steps:

- Extract the "Data_1.0.zip" file into the hard drive.
- Open Microsoft Excel.
- On the "Tools" menu, select the "Add-Ins..." option.
- Click on the "Browse" button, search for the "Data_1.0.xla" file and open it.
- Click the "OK" button.

With this steps, the "Properties Databank 1.0" Add-In will be installed, and will be run every time you open Excel. After installing the Add-In, the "Properties Databank" option will appear in the "Tools" menu, and you will be able to search for the above properties by clicking on it.


I hope this file to be usefull. If you like it, distribute it to your friends, but notify me by e-mail so I can keep track of the copies. Sugestions and comments will be welcome at:

Pedro Fajardo
ppfk@yahoo.com
1999.

IMPORTANT:
-----------
THE FILES WITHIN THIS PACKAGE ARE COPYRIGHTED. THESE FILES CAN BE USED WITHOUT ANY COST, AND THE ENTIRE PACKAGE MAY BE FREELY DISTRIBUTED WITH NOTIFICATION TO THE AUTHOR. SELLING, HIRING OR ANY OTHER USAGE OF THIS FILES WITH ECONOMICAL PURPOSE IS PROHIBITED.

THE AUTHOR DOES NOT ASSUME ANY RESPONSABILITY FOR PROBLEMS CAUSED TO YOUR SYSTEM BY THIS FILE, BEEING THIS OF LOSS OR CORRUPTION OF INFORMATION OR ANY OTHER KIND, AND THE USER MUST ASSUME THE ENTIRE COST OF THE DAMAGES. THE AUTHOR DOES NOT CERTIFY THE VALIDITY OF THE DATA CONTAINED WITHIN THE PROGRAM, AND DOES NOT ASSUME ANY RESPONSABILITY FOR THE RESULTS OBTAINED USING THIS FILE. THE USER MUST ASSUME THE ENTIRE COST.

THE INSTALATION OR OPPENING OF THE ADD-IN INCLUDED IN THIS PACKAGE IMPLIES THE ACCEPTANCE OF THE PREVIOUS TERMS.