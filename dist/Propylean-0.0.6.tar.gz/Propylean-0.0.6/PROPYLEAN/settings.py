class Settings(object):
    unit_system = "SI"
    pipe_dp_method = "Clamond"
    Darcy = True
    compressor_process = "Adiabatic" # Polytropic or Adiabatic/Isentropic